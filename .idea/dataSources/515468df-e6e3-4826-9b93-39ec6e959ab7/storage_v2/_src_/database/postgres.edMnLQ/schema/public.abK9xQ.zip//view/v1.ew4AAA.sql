CREATE VIEW v1 AS
  SELECT emp.ename,
    emp.job,
    emp.sal
   FROM emp
  WHERE ((emp.job)::text = 'CLERK'::text);

