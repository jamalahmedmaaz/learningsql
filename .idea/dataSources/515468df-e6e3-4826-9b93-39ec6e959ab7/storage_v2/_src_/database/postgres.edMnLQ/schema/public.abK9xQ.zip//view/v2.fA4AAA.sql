CREATE VIEW v2 AS
  SELECT emp.empno,
    emp.ename,
    emp.job,
    emp.mgr,
    emp.hiredate,
    emp.sal,
    emp.comm,
    emp.deptno
   FROM emp
  WHERE (emp.deptno <> 10)
UNION ALL
 SELECT emp.empno,
    emp.ename,
    emp.job,
    emp.mgr,
    emp.hiredate,
    emp.sal,
    emp.comm,
    emp.deptno
   FROM emp
  WHERE ((emp.ename)::text = 'WARD'::text);

