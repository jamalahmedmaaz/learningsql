CREATE VIEW v AS
  SELECT (((emp.ename)::text || ' '::text) || emp.deptno) AS data
   FROM emp;

